package com.doodleblue.whatsappchecker.model.dto

open class Contact(var name: String, var phoneNumber: String)