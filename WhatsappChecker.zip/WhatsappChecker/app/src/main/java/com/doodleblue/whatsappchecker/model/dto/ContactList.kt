package com.doodleblue.whatsappchecker.model.dto

class ContactList {
    val data: MutableList<Contact>?= null
}