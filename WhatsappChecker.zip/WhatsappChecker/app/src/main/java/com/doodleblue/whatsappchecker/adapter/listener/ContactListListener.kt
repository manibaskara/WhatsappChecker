package com.doodleblue.whatsappchecker.adapter.listener

import com.doodleblue.whatsappchecker.model.dto.Contact

interface ContactListListener: BaseRecyclerAdapterListener<Contact>
